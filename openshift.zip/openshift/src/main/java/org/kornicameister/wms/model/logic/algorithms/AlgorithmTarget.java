package org.kornicameister.wms.model.logic.algorithms;

/**
 * @author kornicameister
 * @since 0.0.1
 */
public enum AlgorithmTarget {
    SUPPLY,
    RECEIPT
}
