package org.kornicameister.wms.model.logic.algorithms.exception;

/**
 * @author kornicameister
 * @since 0.0.1
 */
public class InsufficientAlgorithmConfigurationException extends Exception {
}
