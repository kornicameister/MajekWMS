/*
 * Project: MajekWMS
 * User   : kornicameister
 * Date   : 04.11.12
 * Time   : 11:27
 */

Ext.define('WMS.view.manager.abstract.Grid', {
    extend    : 'Ext.grid.Panel',
    autoScroll: true
});