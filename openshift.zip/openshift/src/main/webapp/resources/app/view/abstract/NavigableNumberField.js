/*
 * Project: MajekWMS
 * User   : kornicameister
 * Date   : 27.10.12
 * Time   : 11:55
 */

Ext.define('WMS.view.abstract.NavigableNumberField', {
    extend           : 'Ext.form.field.Number',
    alias            : 'widget.navnumberfield',
    keyNavEnabled    : true,
    mouseWheelEnabled: true,
    allowBlank       : true
});
