/*
 * Project: MajekWMS
 * User   : kornicameister
 * Date   : 02.11.12
 * Time   : 15:15
 */

Ext.define('WMS.view.manager.recipient.Details', {
    extend            : 'WMS.view.manager.abstract.ClientDetails',
    uses              : [
        'WMS.view.manager.abstract.ClientDetails'
    ],
    alternateClassName: 'WMS.panel.details.Recipient',
    alias             : 'widget.recipientdetails',
    title             : 'Szczegóły odbiorcy'
});