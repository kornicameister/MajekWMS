/*
 * Project: MajekWMS
 * User   : kornicameister
 * Date   : 04.11.12
 * Time   : 02:31
 */

Ext.define('WMS.controller.manager.Suppliers', {
    extend                    : 'Ext.app.Controller',
    refs                      : [
        { ref: 'managerUI', selector: 'suppliermanager' },
        { ref: 'supplierList', selector: 'suppliermanager clientgrid'},
        { ref: 'detailsView', selector: 'suppliermanager supplierdetails'},
        { ref: 'invoicesView', selector: 'suppliermanager supplierinvoices'}
    ],
    stores                    : [
        'Cities',
        'ClientTypes',
        'Suppliers',
        'Invoices'
    ],
    config                    : {
        invoicesWindow: undefined
    },
    init                      : function () {
        console.init('WMS.controller.manager.Suppliers is initializing...');
        var me = this;
        me.control({
            'suppliermanager toolbar button[itemId=newClient]'    : {
                'click': me.onNewClientAddClick
            },
            'suppliermanager toolbar button[itemId=removeClient]' : {
                'click': me.onRemoveClientClick
            },
            'suppliermanager toolbar button[itemId=editClient]'   : {
                'click': me.onEditClientClick
            },
            'suppliermanager toolbar button[itemId=detailsClient]': {
                'click': me.onDetailsClientClickButton
            },
            'suppliermanager toolbar button[itemId=releaseClient]': {
                'click': me.onReleaseClientClick
            },
            'suppliermanager toolbar button[itemId=newInvoice]'   : {
                'click': me.onNewInvoiceClick
            },
            'suppliermanager clientgrid'                          : {
                'itemdblclick': me.onDetailsClientClickGrid
            },
            'suppliermanager supplierinvoices'                    : {
                'render'      : me.onInvoiceListRendered,
                'itemdblclick': me.onProductsOnInvoiceClick
            }
        });
        me.callParent(arguments);

        me.setInvoicesWindow(Ext.create('Ext.window.Window', {
            title      : 'Produkty na fakturze',
            layout     : 'fit',
            closable   : true,
            closeAction: 'hide',
            movable    : true,
            scrollable : true,
            items      : {
                xtype  : 'grid',
                flex   : 2,
                columns: [
                    {
                        xtype: 'rownumberer'
                    },
                    {
                        header   : 'Produkt',
                        dataIndex: 'product_id',
                        width    : 130,
                        renderer : function (product_id) {
                            var product = me.getInvoicesStore().findByProduct(product_id);
                            return product.get('name');
                        }
                    },
                    {
                        header     : 'Palet',
                        dataIndex  : 'pallets',
                        summaryType: 'sum',
                        width      : 50
                    },
                    {
                        header     : 'Cena',
                        dataIndex  : 'price',
                        summaryType: 'average',
                        renderer   : function (val) {
                            return val + ' zł'
                        },
                        width      : 50
                    },
                    {
                        header   : 'Podatek',
                        dataIndex: 'tax',
                        renderer : function (value) {
                            return value + ' %';
                        }
                    },
                    {
                        header   : 'Cena VAT',
                        dataIndex: 'summaryPrice',
                        width    : 70
                    },
                    {
                        header   : 'Opis',
                        dataIndex: 'comment',
                        flex     : 3
                    }
                ]
            }
        }));
    },
    onProductsOnInvoiceClick  : function (grid, invoice) {
        var me = this,
            popup = me.getInvoicesWindow(),
            invoicesStore = me.getInvoicesStore(),
            gridInWindow = popup.down('grid');
        gridInWindow.reconfigure((function () {
            var data = invoicesStore.findInvoices(invoice.getId(), 'invoice');
            return Ext.create('Ext.data.Store', {
                model: 'WMS.model.entity.InvoiceProduct',
                data : data
            })
        }()));
        popup.show();
    },
    onInvoiceListRendered     : function () {
        var me = this,
            grid = me.getInvoicesView(),
            clientRenderer = function (client_id) {
                if (!Ext.isDefined(client_id) || client_id === 0) {
                    return '';
                } else if (Ext.isString(client_id)) {
                    client_id = parseInt(client_id);
                }
                return me.getSuppliersStore().getById(client_id).get('name');
            },
            dateRenderer = function (date) {
                return Ext.Date.format(date, 'Y-n-j');
            },
            timeRenderer = function (days) {
                return Ext.String.format('{0} dni', days);
            };

        grid.columns[1]['renderer'] = clientRenderer;
        grid.columns[2]['renderer'] = dateRenderer;
        grid.columns[3]['renderer'] = timeRenderer;
        grid.columns[4]['renderer'] = dateRenderer;

    },
    onNewInvoiceClick         : function () {
        var me = this,
            invoiceWizardCtrl = me.getController('WMS.controller.wizard.Invoice');

        invoiceWizardCtrl.openAsSupply();
    },
    onDetailsClientRequest    : function (client) {
        var me = this,
            detailsView = me.getDetailsView(),
            invoiceView = me.getInvoicesView(),
            data = client.getData(true);

        if (Ext.isDefined(client) && Ext.isDefined(detailsView)) {
            detailsView.update(data);
            invoiceView.reconfigure((function () {
                var client_id = client.getId(),
                    invoicesStore = me.getInvoicesStore(),
                    invoices = invoicesStore.findInvoices(client_id, 'client');

                return Ext.create('Ext.data.Store', {
                    model: 'WMS.model.entity.Invoice',
                    data : invoices
                });

            }()));
            me.popupDetailsView();

            Ext.getCmp('statusBar').setStatus({
                text : Ext.String.format('Wyświetlam szczegóły dostawcy {0}', client.get('name')),
                clear: {
                    wait       : 10000,
                    anim       : true,
                    useDefaults: false
                }
            })
        }
    },
    onReleaseClientClick      : function () {
    },
    onNewClientAddClick       : function () {
        var me = this,
            clientWizardCtrl = me.getController('WMS.controller.wizard.Client');

        if (Ext.isDefined(clientWizardCtrl)) {
            clientWizardCtrl.openAsSupplier();
        }
    },
    onEditClientClick         : function () {

    },
    onRemoveClientClick       : function () {
        var me = this,
            store = me.getSuppliersStore(),
            selection = me.getSelectedClients();
        if (selection) {
            store.remove(selection);
            Ext.getCmp('statusBar').setStatus({
                text : Ext.String.format('Usunąłeś {0} {1}',
                    selection.length,
                    selection.length > 0 ? 'dostawców' : 'dostawcę'),
                clear: {
                    wait       : 10000,
                    anim       : true,
                    useDefaults: false
                }
            });
        }
    },
    //-----------UTILS and WRAPPERS ----------------//
    /**
     * Utility method returning selected clients.
     * Selection is understood as rows being currently selected
     * in the clients list
     * @return {*}
     */
    getSelectedClients        : function () {
        var me = this;
        return me.getSupplierList().getView().getSelectionModel().getSelection();
    },
    popupDetailsView          : function () {
        var me = this,
            managerUI = me.getManagerUI(),
            detailsView = managerUI['items'].get('supplierDetailsHolder');
        if (Ext.isDefined(detailsView)) {
            detailsView.expand();
        } else {
            console.log('manager.Recipients :: Failed to popup with statistics')
        }
    }, /**
     * Method used as wrapper for the right method which is
     * to process the request
     * @param grid
     * @param record
     */
    onDetailsClientClickGrid  : function (grid, record) {
        var me = this;
        me.onDetailsClientRequest(record);
    },
    /**
     * Wrapper for the method used to display details for
     * selected client. It is called as the reaction for clicking
     * button in bottom toolbar.
     */
    onDetailsClientClickButton: function () {
        var me = this,
            selection = me.getSelectedClients();
        me.onDetailsClientRequest(selection[0]);
    }
});
