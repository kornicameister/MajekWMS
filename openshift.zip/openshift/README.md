MajekWMS
========

This repository holds source code of my Engineering Thesis at Logistic field of studies.

Features:
<ol>
 <li>View on warehouse schema</li>
 <li>Detailed view on selected part of warehouse</li>
 <li>Receiving of new goods to warehouse</li>
 <li>Relasing of selected groups/parts of goods</li>
 <li>Simulating invoices</li>
</ol>

Used technology:
<ol>
 <li>ExtJS 4.1</li>
 <li>Apache Tomcat 7.0</li>
 <li>Eclipse 4.2.0</li>
 <li>Linux Mint 12 Maya</li>
 <li>Git</li>
</ol>